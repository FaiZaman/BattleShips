
public enum ShotStatus
{
    HIT, MISS, SUNK
}
