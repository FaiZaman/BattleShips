
/**
 * Represents the status of a ship or one square of a ship
 */
public enum ShipStatus
{
    NONE, INTACT, HIT, SUNK
}
